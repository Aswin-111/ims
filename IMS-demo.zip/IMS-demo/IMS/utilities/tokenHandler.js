const jwtoken = require('jsonwebtoken');

module.exports = {
    generateToken: (data) => {
        return jwtoken.sign(data, "JHGHJSAGJGJASGJSA", {
            expiresIn: '7d'
        });
    },
    verifyToken: (token) => {
        return jwtoken.verify(token, "JHGHJSAGJGJASGJSA");
    },
    decodeToken: (token) => {
        return jwtoken.decode(token);
    }
}