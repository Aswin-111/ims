const express = require('express');
const accountsRoute = require('./apps/accounts/routes');
const adminRoute = require('./apps/admin/routes');
const parser = require('body-parser');
const app = express();

app.use(parser.json({inflate:true}));
app.use("/api/v1/accounts", accountsRoute);
app.use("/api/v1/admin", adminRoute);

app.listen(80);

