const admin = require('./controllers/adminController');
const course = require('./controllers/courseController');
const mark = require('./controllers/markController');
const feedback = require('./controllers/feedbackController');
const express = require('express');
const router = express.Router();

router.post('/student/create', admin.createStudent);

router.post('/course/create', course.create);
router.post('/course/', course.getAll);
router.post('/course/:id', course.getOne);
router.post('/course/update/:id', course.update);
router.post('/course/delete/:id', course.delete);

// router.post('/mark/', mark.getAll);
// router.post('/mark/:id', mark.getOne);
router.post('/mark/create', mark.create);
router.post('/mark/update/:id', mark.update);
router.post('/mark/delete/:id', mark.delete);

router.post('/feedback/', feedback.getAll);
router.post('/feedback/:id', feedback.getOne);

module.exports = router;