const {LoginCredentials, User} = require('../../../models/db');
const ResponseModel = require('../../../utilities/responseModel');
const tokenHandler = require('../../../utilities/tokenHandler');


module.exports.login = async (req, res) => {
    const {email, password} = req.body;

    var login = await LoginCredentials.findOne({
        where: {
            email: email,
            password: password
        },
        include: User
    });

    if (!login) {
        var result = new ResponseModel(null, "Invalid credentials", ["Invalid credentials"]);
        return res.json(result);
    }

    // return res.json(new ResponseModel(login, "Login successful"));

    // Generate toke
    var token = tokenHandler.generateToken({
        id: login.dataValues.user_id,
        email: login.dataValues.email,
        role: login.dataValues.User.dataValues.role,
    });
    return res.json(new ResponseModel(token, "Login successful"));
}

// Register user
module.exports.createAdmin = async (req, res) => {

    // Check if user already exists
    var user = await User.findOne({
        where: {
            role: 'a'
        }
    });

    if (user) {
        return res.json(new ResponseModel(null, "Admin already exists", ["Admin already exists"]));
    }

    // Create user
    var user = await User.create({
        name: "Admin",
        role: "a",
        dob: "1999-01-01",
        address: "Admin address",
        phone: "1234567890"
    });

    login = await LoginCredentials.create({
        email: "admin@admin.com",
        password: "Pass@123",
        user_id: user.user_id
    });

    return res.json(new ResponseModel(null, "Admin created successfully"));
}
